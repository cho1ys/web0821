// const add = function(a: number,b:number):number{
//     return a+b
// }
// function add2(a: number,b:number):number{
//     return a+b
// }
// const result1 = add2(1,2)

// const str = "hello"
// const num = 123
// const bool = false
// const n = null
// const u = undefined
// const sym = Symbol('sym')
// const obj = {hello : 'world'}

// let str = "hello"
// let num = 123
// let bool = false
// let n = null
// let u = undefined
// let sym = Symbol('sym')
// let obj = {hello : 'world'}

// let str : 'hello' = 'hello'

// const obj = {name : 'kim'}
// const arr = [1,2,'three'] as const
// obj.name = 'choi'
// arr.push(4)

// const arr1:string[] = ['1', '2','3']
// const arr2: Array<number> = [1,2,3]
// const arr3 = [1,'2',3]
// const arr4 = []

// const tuple:readonly[number,boolean,string] = [1, true, 'hello']
// tuple[0] = 3
// tuple[2] = 'world'
// tuple.push('hi')
// console.log(tuple)

// const strNumberBools:[string,number,...boolean[]] = ['hello',1,false,true,false]
// const[a,...rest]=['hello',1,2,3]
// const[b,...rest2]:[string,...number[]]=['hello',1,2,3]

// function add(x:number, y:number){
//     return x+y
// }
// const str1 = 'hello'
// const str2 = str1

// const result1 : add(1,2) = add(1,2)
// const result2 : typeof add(1,2) = add(1,2)

// const add2: typeof add = (x:number, y:number) => x+y

// const arr = [];
// arr.push('1')
// arr;
// arr.push(3)
// arr;

// const a:any = '123'
// const any1 = a+1
// const any2 = a-1
// const any3 = a*1
// const any4 = a+'1'
// const any5 = a/1

// fetch('url').then<{data :string}>(res =>{
//     return res.json()
// }).then(result =>{

// })
// const result:{hello:string} = JSON.parse('{"hello":"json"}')

let name1 = 'kim'

function add(a:number,b:number){
    return a+b
}
function isEven(num:number){
    return num%2 ===0
}